CREATE DATABASE IF NOT EXISTS `dulosseg31library` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `dulosseg31library`;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_ID` int(11) NOT NULL,
  `book_Name` varchar(255) NOT NULL,
  `ISBN` varchar(255) NOT NULL,
  `Author` varchar(255) NOT NULL,
  `book_cover` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_ID`, `book_Name`, `ISBN`, `Author`, `book_cover`) VALUES
(1, 'Head First 2nd Edition', '978-0596009205', 'Kathy Sierra & Bert Bates', 'https://images-na.ssl-images-amazon.com/images/I/51Gsycdh-TL._SX430_BO1,204,203,200_.jpg'),
(2, 'Clean Code: A Handbook of Agile Software Craftsmanship 1st Edition', '978-0132350884', 'Robert C. Martin', 'https://images-na.ssl-images-amazon.com/images/I/41-+g1a2Y1L._SX375_BO1,204,203,200_.jpg'),
(3, 'Design Patterns: Elements of Reusable Object-Oriented Software 1st Edition', '978-0201633610', 'Erich Gamma, Richard Helm, Ralph Johnson, \r\nJohn Vlissides, and Grady Booch', 'https://images-na.ssl-images-amazon.com/images/I/51szD9HC9pL._SX395_BO1,204,203,200_.jpg'),
(4, 'The Pragmatic Programmer: Your Journey To Mastery, 20th Anniversary Edition (2nd Edition) ', '978-0135957059', 'David Thomas & Andrew Hunt', 'https://images-na.ssl-images-amazon.com/images/I/51cUVaBWZzL._SX380_BO1,204,203,200_.jpg'),
(5, 'Cracking the Coding Interview: 189 Programming Questions and Solutions 6th Edition', '978-0984782857', 'Gayle Laakmann McDowell', 'https://images-na.ssl-images-amazon.com/images/I/410hiaPGyCL._SX348_BO1,204,203,200_.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;